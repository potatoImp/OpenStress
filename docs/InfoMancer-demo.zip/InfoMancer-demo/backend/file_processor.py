from typing import Dict, Any
from docx import Document
from PyPDF2 import PdfReader
from openpyxl import load_workbook
from xmindparser import xmind_to_dict
import os

class FileProcessor:
    @staticmethod
    def process_txt(file_path: str) -> str:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    @staticmethod
    def process_docx(file_path: str) -> str:
        doc = Document(file_path)
        return '\n'.join([paragraph.text for paragraph in doc.paragraphs])
    
    @staticmethod
    def process_pdf(file_path: str) -> str:
        reader = PdfReader(file_path)
        text = ''
        for page in reader.pages:
            text += page.extract_text() + '\n'
        return text
    
    @staticmethod
    def process_excel(file_path: str) -> str:
        wb = load_workbook(file_path)
        text = []
        for sheet in wb.sheetnames:
            ws = wb[sheet]
            text.append(f'Sheet: {sheet}')
            for row in ws.iter_rows(values_only=True):
                text.append('\t'.join(str(cell) for cell in row if cell is not None))
        return '\n'.join(text)
    
    @staticmethod
    def process_xmind(file_path: str) -> str:
        content = xmind_to_dict(file_path)
        def extract_text(node: Dict[str, Any], level: int = 0) -> str:
            text = '\t' * level + node.get('title', '') + '\n'
            for child in node.get('topics', []):
                text += extract_text(child, level + 1)
            return text
        
        result = []
        for sheet in content:
            result.append(f"Sheet: {sheet.get('title', '')}")
            for topic in sheet.get('topics', []):
                result.append(extract_text(topic))
        return '\n'.join(result)
    
    @staticmethod
    def process_file(file_path: str, content_type: str) -> str:
        # 根据文件类型选择相应的处理方法
        processors = {
            'text/plain': FileProcessor.process_txt,
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': FileProcessor.process_docx,
            'application/pdf': FileProcessor.process_pdf,
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': FileProcessor.process_excel,
            'application/x-xmind': FileProcessor.process_xmind
        }
        
        processor = processors.get(content_type)
        if not processor:
            raise ValueError(f'Unsupported file type: {content_type}')
        
        return processor(file_path)