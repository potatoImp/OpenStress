from typing import List, Dict, Any
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
import os

class VectorStore:
    def __init__(self):
        self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
        self.client = chromadb.Client(Settings(
            chroma_db_impl="duckdb+parquet",
            persist_directory="vector_db"
        ))
        self.collection = self.client.get_or_create_collection("documents")
    
    def add_document(self, doc_id: str, content: str, metadata: Dict[str, Any] = None):
        # 将文档分割成段落
        paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
        
        # 为每个段落生成向量
        embeddings = self.model.encode(paragraphs)
        
        # 为每个段落生成唯一ID
        ids = [f"{doc_id}_p{i}" for i in range(len(paragraphs))]
        
        # 添加到向量数据库
        self.collection.add(
            embeddings=embeddings.tolist(),
            documents=paragraphs,
            ids=ids,
            metadatas=[{"doc_id": doc_id, **metadata} for _ in range(len(paragraphs))]
        )
    
    def search(self, query: str, n_results: int = 5) -> List[Dict[str, Any]]:
        # 将查询转换为向量
        query_embedding = self.model.encode(query)
        
        # 在向量数据库中搜索
        results = self.collection.query(
            query_embeddings=query_embedding.tolist(),
            n_results=n_results
        )
        
        # 整理搜索结果
        search_results = []
        for i in range(len(results['ids'][0])):
            search_results.append({
                'id': results['ids'][0][i],
                'content': results['documents'][0][i],
                'metadata': results['metadatas'][0][i],
                'distance': results['distances'][0][i]
            })
        
        return search_results
    
    def delete_document(self, doc_id: str):
        # 获取所有与文档相关的段落ID
        results = self.collection.get(where={"doc_id": doc_id})
        if results and results['ids']:
            # 删除所有相关段落
            self.collection.delete(ids=results['ids'])