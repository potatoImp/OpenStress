from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
import os
import uuid
from datetime import datetime
from qa_system import QASystem

app = FastAPI()

# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 文件上传目录
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 初始化QA系统
qa_system = QASystem()

# 文件列表
files_db = []

@app.post("/api/uploadfile")
async def upload_file(file: UploadFile = File(...)):
    try:
        # 生成唯一文件名
        file_id = str(uuid.uuid4())
        extension = os.path.splitext(file.filename)[1]
        file_path = os.path.join(UPLOAD_DIR, f"{file_id}{extension}")
        
        # 保存文件
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        # 保存文件信息
        file_info = {
            "id": file_id,
            "filename": file.filename,
            "filetype": file.content_type,
            "uploadTime": datetime.now().isoformat(),
            "path": file_path
        }
        files_db.append(file_info)
        
        # 处理并存储文档
        qa_system.process_and_store_document(
            file_id,
            file_path,
            file.content_type,
            {"filename": file.filename}
        )
        
        return {"status": "success", "file_id": file_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/files")
async def get_files() -> List[Dict[str, Any]]:
    return files_db

@app.delete("/api/files/{file_id}")
async def delete_file(file_id: str):
    try:
        # 查找文件信息
        file_info = next((f for f in files_db if f["id"] == file_id), None)
        if not file_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        # 删除物理文件
        if os.path.exists(file_info["path"]):
            os.remove(file_info["path"])
        
        # 从文件列表中移除
        files_db.remove(file_info)
        
        # 从向量数据库中删除
        qa_system.delete_document(file_id)
        
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/qa")
async def answer_question(query: Dict[str, Any]):
    try:
        answer = qa_system.answer_question(query["question"], n_results=5)
        return answer
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/files/{file_id}/content")
async def get_file_content(file_id: str):
    file = next((f for f in files_db if f["id"] == file_id), None)
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        with open(file["path"], "r", encoding="utf-8") as f:
            content = f.read()
        return {"content": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/files/{file_id}")
async def delete_file(file_id: str):
    file = next((f for f in files_db if f["id"] == file_id), None)
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        os.remove(file["path"])
        files_db.remove(file)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))