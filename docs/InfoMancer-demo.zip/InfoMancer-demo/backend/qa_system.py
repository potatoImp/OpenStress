from typing import Dict, Any
from file_processor import FileProcessor
from vector_store import VectorStore

class QASystem:
    def __init__(self):
        self.vector_store = VectorStore()
        self.file_processor = FileProcessor()
    
    def process_and_store_document(self, file_id: str, file_path: str, content_type: str, metadata: Dict[str, Any] = None):
        # 处理文档内容
        content = self.file_processor.process_file(file_path, content_type)
        
        # 存储到向量数据库
        self.vector_store.add_document(file_id, content, metadata)
    
    def delete_document(self, doc_id: str):
        # 从向量数据库中删除文档
        self.vector_store.delete_document(doc_id)
    
    def answer_question(self, query: str, n_results: int = 5) -> Dict[str, Any]:
        # 搜索相关文档片段
        search_results = self.vector_store.search(query, n_results)
        
        # 构建上下文
        context = '\n'.join([result['content'] for result in search_results])
        
        # 构建答案
        answer = {
            'answer': '根据相关文档内容，我找到以下信息：\n\n' + context,
            'sources': [{
                'id': result['metadata'].get('doc_id'),
                'filename': result['metadata'].get('filename', '未知文件'),
                'content': result['content'],
                'relevance': 1 - result['distance']  # 将距离转换为相关度分数
            } for result in search_results]
        }
        
        return answer