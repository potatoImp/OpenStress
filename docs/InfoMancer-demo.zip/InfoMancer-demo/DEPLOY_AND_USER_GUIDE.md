# InfoMancer 部署与使用手册

## 目录
- [部署指南](#部署指南)
  - [Windows部署](#windows部署)
  - [Linux部署](#linux部署)
- [使用手册](#使用手册)
  - [系统功能概述](#系统功能概述)
  - [操作指南](#操作指南)
  - [常见问题](#常见问题)

## 部署指南

### Windows部署

#### 环境要求
- Python 3.8+
- Node.js 16+
- npm 8+

#### 部署步骤

1. 克隆项目
```bash
git clone [项目地址]
cd InfoMancer-demo
```

2. 安装后端依赖
```bash
cd backend
pip install -r requirements.txt
```

3. 安装前端依赖
```bash
npm install
```

4. 启动后端服务
```bash
cd backend
python main.py
```

5. 启动前端服务
```bash
npm run dev
```

### Linux部署

#### 环境要求
- Python 3.8+
- Node.js 16+
- npm 8+

#### 系统要求
- CPU: 2核心及以上
- 内存: 4GB及以上
- 磁盘空间: 10GB及以上
- 操作系统: Ubuntu 18.04/20.04 LTS, CentOS 7/8

#### 网络配置
1. 端口要求
```bash
# 后端服务端口
firewall-cmd --permanent --add-port=5000/tcp

# 前端服务端口
firewall-cmd --permanent --add-port=4173/tcp

# 重新加载防火墙配置
firewall-cmd --reload
```

2. 环境变量配置
```bash
# 添加到 ~/.bashrc 或 /etc/profile
export PYTHONPATH=/path/to/infomancer/backend:$PYTHONPATH
export NODE_ENV=production
```

#### 服务管理
1. 创建系统服务
```bash
# 创建后端服务配置
cat > /etc/systemd/system/infomancer-backend.service << EOF
[Unit]
Description=InfoMancer Backend Service
After=network.target

[Service]
User=your_user
WorkingDirectory=/path/to/infomancer/backend
Environment=PATH=/path/to/infomancer/backend/venv/bin:$PATH
ExecStart=/path/to/infomancer/backend/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# 创建前端服务配置
cat > /etc/systemd/system/infomancer-frontend.service << EOF
[Unit]
Description=InfoMancer Frontend Service
After=network.target

[Service]
User=your_user
WorkingDirectory=/path/to/infomancer
ExecStart=/usr/bin/npm run preview
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# 启动服务
systemctl daemon-reload
systemctl enable infomancer-backend
systemctl enable infomancer-frontend
systemctl start infomancer-backend
systemctl start infomancer-frontend
```

#### 部署验证
1. 检查服务状态
```bash
# 检查后端服务状态
systemctl status infomancer-backend

# 检查前端服务状态
systemctl status infomancer-frontend

# 检查端口监听状态
ss -tunlp | grep -E '5000|4173'
```

2. 访问测试
- 访问前端页面: http://your_server_ip:4173
- 测试后端API: http://your_server_ip:5000/api/health

3. 查看日志
```bash
# 查看后端日志
journalctl -u infomancer-backend -f

# 查看前端日志
journalctl -u infomancer-frontend -f
```

#### 手动部署步骤

1. 安装依赖
```bash
# 安装Python依赖
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 安装Node.js依赖
cd ..
npm install
```

2. 启动服务
```bash
# 启动后端服务
cd backend
python3 main.py

# 启动前端服务
cd ..
npm run dev
```

## 使用手册

### 系统功能概述

InfoMancer是一个智能文档管理与知识检索系统，主要功能包括：

1. 文件管理
   - 支持多种格式文件上传（TXT、DOCX、PDF、Excel、XMind等）
   - 文件列表查看和管理
   - 文件内容预览

2. 智能检索
   - 基于向量的文档内容检索
   - 智能问答功能
   - 相关文档推荐

### 操作指南

#### 1. 文件上传
1. 点击"文件上传"页面
2. 将文件拖拽到上传区域或点击选择文件
3. 等待文件上传和处理完成

#### 2. 文件管理
1. 在"文件管理"页面查看已上传的文件列表
2. 可以预览文件内容
3. 点击删除按钮可以移除不需要的文件

#### 3. 智能问答
1. 进入"智能问答"页面
2. 在输入框中输入您的问题
3. 系统会基于已上传的文档内容进行回答
4. 同时会显示相关的参考文档

### 常见问题

#### 1. 文件上传失败
- 检查文件格式是否支持
- 确保文件大小在合理范围内
- 检查网络连接是否正常

#### 2. 系统无法启动
- 确认所有依赖已正确安装
- 检查端口是否被占用
- 查看日志文件了解具体错误信息

#### 3. 智能问答没有返回结果
- 确保已上传相关文档
- 尝试使用更具体的问题描述
- 检查文档是否已被正确处理和存储