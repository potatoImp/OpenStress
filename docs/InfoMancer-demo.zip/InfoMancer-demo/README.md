# InfoMancer - 智能文档管理与知识检索系统

## 项目简介
InfoMancer是一个基于Web的智能文档管理系统，支持多种格式文件的上传、内容提取、存储与检索。系统能够自动解析不同类型的文档，将内容结构化存储，并提供智能问答和检索功能。

## 主要功能
- 多格式文件上传与解析（支持TXT、DOCX、PDF、Excel、XMind等格式）
- 智能内容提取与结构化存储
- 基于向量的知识检索
- 智能问答功能
- 文件管理与内容监控

## 技术架构
### 后端技术栈
- FastAPI：Web框架
- Chromadb：向量数据库
- Sentence-Transformers：文本向量化
- 文件解析库：
  - Python-docx：DOCX文件解析
  - PyPDF2：PDF文件解析
  - Openpyxl：Excel文件解析
  - XMind SDK：XMind文件解析

### 前端技术栈
- React + Vite：前端框架
- Ant Design：UI组件库
- Axios：HTTP客户端

### 存储方案
- 文件存储：服务器本地存储
- 知识存储：Chromadb向量数据库

## 系统架构
1. 文件上传与处理模块
2. 内容提取与向量化模块
3. 知识存储与检索模块
4. 问答交互模块
5. 文件管理模块

## 安装与部署
（待补充）

## 使用说明
（待补充）

## 开发指南
（待补充）

## 许可证
MIT License