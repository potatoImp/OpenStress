import React from 'react'
import { Layout, Menu } from 'antd'
import { Routes, Route, Link } from 'react-router-dom'
import { UploadOutlined, FileSearchOutlined, QuestionCircleOutlined } from '@ant-design/icons'

// 导入页面组件（稍后创建）
import FileUpload from './pages/FileUpload'
import FileManagement from './pages/FileManagement'
import QASystem from './pages/QASystem'

const { Header, Content, Sider } = Layout

const App = () => {
  const menuItems = [
    {
      key: 'upload',
      icon: <UploadOutlined />,
      label: <Link to="/upload">文件上传</Link>
    },
    {
      key: 'management',
      icon: <FileSearchOutlined />,
      label: <Link to="/management">文件管理</Link>
    },
    {
      key: 'qa',
      icon: <QuestionCircleOutlined />,
      label: <Link to="/qa">智能问答</Link>
    }
  ]

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header style={{ padding: 0, background: '#fff' }}>
        <div style={{ float: 'left', width: '200px', height: '31px', margin: '16px 24px 16px 0', background: 'rgba(0, 0, 0, 0.2)' }} />
      </Header>
      <Layout>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['upload']}
            style={{ height: '100%', borderRight: 0 }}
            items={menuItems}
          />
        </Sider>
        <Layout style={{ padding: '24px' }}>
          <Content style={{ padding: 24, margin: 0, minHeight: 280, background: '#fff' }}>
            <Routes>
              <Route path="/upload" element={<FileUpload />} />
              <Route path="/management" element={<FileManagement />} />
              <Route path="/qa" element={<QASystem />} />
              <Route path="/" element={<FileUpload />} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </Layout>
  )
}

export default App