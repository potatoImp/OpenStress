import React, { useState, useEffect } from 'react'
import { Table, Card, Button, Space, Modal, message } from 'antd'
import { DeleteOutlined, EyeOutlined } from '@ant-design/icons'
import axios from 'axios'

const FileManagement = () => {
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(false)
  const [previewVisible, setPreviewVisible] = useState(false)
  const [previewContent, setPreviewContent] = useState('')

  useEffect(() => {
    fetchFiles()
  }, [])

  const fetchFiles = async () => {
    setLoading(true)
    try {
      const response = await axios.get('/api/files')
      setFiles(response.data)
    } catch (error) {
      message.error('获取文件列表失败')
    }
    setLoading(false)
  }

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/files/${id}`)
      message.success('文件删除成功')
      fetchFiles()
    } catch (error) {
      message.error('文件删除失败')
    }
  }

  const handlePreview = async (id) => {
    try {
      const response = await axios.get(`/api/files/${id}/content`)
      setPreviewContent(response.data.content)
      setPreviewVisible(true)
    } catch (error) {
      message.error('获取文件内容失败')
    }
  }

  const columns = [
    {
      title: '文件名',
      dataIndex: 'filename',
      key: 'filename',
    },
    {
      title: '文件类型',
      dataIndex: 'filetype',
      key: 'filetype',
    },
    {
      title: '上传时间',
      dataIndex: 'uploadTime',
      key: 'uploadTime',
      render: (text) => new Date(text).toLocaleString(),
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => handlePreview(record.id)}
          >
            预览
          </Button>
          <Button
            type="text"
            danger
            icon={<DeleteOutlined />}
            onClick={() => handleDelete(record.id)}
          >
            删除
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <div>
      <Card title="文件管理">
        <Table
          columns={columns}
          dataSource={files}
          rowKey="id"
          loading={loading}
        />
      </Card>

      <Modal
        title="文件预览"
        visible={previewVisible}
        onCancel={() => setPreviewVisible(false)}
        footer={null}
        width={800}
      >
        <pre style={{ whiteSpace: 'pre-wrap', maxHeight: '60vh', overflow: 'auto' }}>
          {previewContent}
        </pre>
      </Modal>
    </div>
  )
}

export default FileManagement