import React, { useState } from 'react'
import { Input, Card, List, Button, Spin, message, Collapse } from 'antd'
import { SendOutlined } from '@ant-design/icons'
import axios from 'axios'

const { TextArea } = Input

const QASystem = () => {
  const [question, setQuestion] = useState('')
  const [loading, setLoading] = useState(false)
  const [chatHistory, setChatHistory] = useState([])

  const handleSubmit = async () => {
    if (!question.trim()) {
      message.warning('请输入问题')
      return
    }

    setLoading(true)
    try {
      const response = await axios.post('/api/qa', { question })
      setChatHistory([...chatHistory, {
        type: 'question',
        content: question
      }, {
        type: 'answer',
        content: response.data.answer,
        sources: response.data.sources
      }])
      setQuestion('')
    } catch (error) {
      message.error('获取答案失败')
    }
    setLoading(false)
  }

  return (
    <div>
      <Card title="智能问答系统" style={{ marginBottom: 24 }}>
        <List
          itemLayout="vertical"
          dataSource={chatHistory}
          renderItem={item => (
            <List.Item>
              <div style={{
                textAlign: item.type === 'question' ? 'right' : 'left',
                marginBottom: 16
              }}>
                <Card
                  style={{
                    display: 'inline-block',
                    maxWidth: '80%',
                    backgroundColor: item.type === 'question' ? '#e6f7ff' : '#f0f2f5'
                  }}
                >
                  <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{item.content}</p>
                  {item.type === 'answer' && item.sources && (
                    <Collapse ghost style={{ marginTop: 16 }}>
                      <Collapse.Panel header="相关文档来源">
                        <List
                          size="small"
                          dataSource={item.sources}
                          renderItem={source => (
                            <List.Item>
                              <Card size="small" style={{ width: '100%' }}>
                                <p><strong>文件名：</strong>{source.filename}</p>
                                <p><strong>相关度：</strong>{(source.relevance * 100).toFixed(2)}%</p>
                                <p><strong>内容片段：</strong></p>
                                <p style={{ whiteSpace: 'pre-wrap' }}>{source.content}</p>
                              </Card>
                            </List.Item>
                          )}
                        />
                      </Collapse.Panel>
                    </Collapse>
                  )}
                </Card>
              </div>
            </List.Item>
          )}
        />
      </Card>

      <Card>
        <div style={{ display: 'flex', gap: 16 }}>
          <TextArea
            value={question}
            onChange={e => setQuestion(e.target.value)}
            placeholder="请输入您的问题"
            autoSize={{ minRows: 2, maxRows: 6 }}
            style={{ flex: 1 }}
          />
          <Button
            type="primary"
            icon={<SendOutlined />}
            onClick={handleSubmit}
            loading={loading}
            style={{ alignSelf: 'flex-end' }}
          >
            发送
          </Button>
        </div>
      </Card>
    </div>
  )
}

export default QASystem