import React, { useState } from 'react'
import { Upload, message, Card, List, Progress } from 'antd'
import { InboxOutlined } from '@ant-design/icons'
import axios from 'axios'

const { Dragger } = Upload

const FileUpload = () => {
  const [fileList, setFileList] = useState([])
  const [uploading, setUploading] = useState(false)

  const props = {
    name: 'file',
    multiple: true,
    action: '/api/uploadfile',
    onChange(info) {
      const { status } = info.file
      if (status === 'done') {
        message.success(`${info.file.name} 文件上传成功。`)
        setFileList([...fileList, info.file])
      } else if (status === 'error') {
        message.error(`${info.file.name} 文件上传失败。`)
      }
    },
    onDrop(e) {
      console.log('Dropped files', e.dataTransfer.files)
    },
    beforeUpload(file) {
      const isValidType = [
        'text/plain',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/x-xmind'
      ].includes(file.type)

      const isLt50M = file.size / 1024 / 1024 < 50

      if (!isValidType) {
        message.error('只支持 TXT、DOCX、PDF、Excel 和 XMind 文件！')
        return false
      }

      if (!isLt50M) {
        message.error('文件大小不能超过50MB！')
        return false
      }

      return true
    }
  }

  return (
    <div>
      <Card title="文件上传" style={{ marginBottom: 24 }}>
        <Dragger {...props}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">点击或拖拽文件到此区域上传</p>
          <p className="ant-upload-hint">
            支持 TXT、DOCX、PDF、Excel 和 XMind 文件格式
          </p>
        </Dragger>
      </Card>

      <Card title="已上传文件">
        <List
          itemLayout="horizontal"
          dataSource={fileList}
          renderItem={item => (
            <List.Item>
              <List.Item.Meta
                title={item.name}
                description={`上传时间: ${new Date(item.lastModified).toLocaleString()}`}
              />
              {item.status === 'uploading' && (
                <Progress percent={item.percent} size="small" />
              )}
            </List.Item>
          )}
        />
      </Card>
    </div>
  )
}

export default FileUpload