#!/bin/bash

# InfoMancer 自动部署脚本

# 检查是否以root权限运行
if [ "$(id -u)" != "0" ]; then
   echo "此脚本需要root权限运行" 
   exit 1
fi

# 设置环境变量
PROJECT_DIR="/opt/infomancer"
BACKEND_DIR="${PROJECT_DIR}/backend"
USER="infomancer"

# 创建系统用户
echo "创建系统用户..."
id -u $USER &>/dev/null || useradd -m -s /bin/bash $USER

# 安装系统依赖
echo "安装系统依赖..."
if [ -f /etc/debian_version ]; then
    # Ubuntu/Debian系统
    apt-get update
    apt-get install -y python3 python3-pip python3-venv nodejs npm git
elif [ -f /etc/redhat-release ]; then
    # CentOS/RHEL系统
    yum install -y epel-release
    yum install -y python3 python3-pip nodejs npm git
fi

# 创建项目目录
echo "创建项目目录..."
mkdir -p $PROJECT_DIR
chown -R $USER:$USER $PROJECT_DIR

# 克隆项目代码
echo "克隆项目代码..."
cd $PROJECT_DIR
su - $USER -c "git clone https://github.com/yourusername/InfoMancer-demo.git ."

# 配置Python环境
echo "配置Python环境..."
su - $USER -c "cd $BACKEND_DIR && python3 -m venv venv"
su - $USER -c "cd $BACKEND_DIR && source venv/bin/activate && pip install -r requirements.txt"

# 安装前端依赖
echo "安装前端依赖..."
su - $USER -c "cd $PROJECT_DIR && npm install"

# 配置防火墙
echo "配置防火墙..."
if command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-port=5000/tcp
    firewall-cmd --permanent --add-port=4173/tcp
    firewall-cmd --reload
fi

# 配置环境变量
echo "配置环境变量..."
cat > /etc/profile.d/infomancer.sh << EOF
export PYTHONPATH=${BACKEND_DIR}:\$PYTHONPATH
export NODE_ENV=production
EOF

source /etc/profile.d/infomancer.sh

# 创建系统服务
echo "创建系统服务..."
cat > /etc/systemd/system/infomancer-backend.service << EOF
[Unit]
Description=InfoMancer Backend Service
After=network.target

[Service]
User=$USER
WorkingDirectory=$BACKEND_DIR
Environment=PATH=$BACKEND_DIR/venv/bin:\$PATH
ExecStart=$BACKEND_DIR/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/infomancer-frontend.service << EOF
[Unit]
Description=InfoMancer Frontend Service
After=network.target

[Service]
User=$USER
WorkingDirectory=$PROJECT_DIR
ExecStart=/usr/bin/npm run preview
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# 启动服务
echo "启动服务..."
systemctl daemon-reload
systemctl enable infomancer-backend
systemctl enable infomancer-frontend
systemctl start infomancer-backend
systemctl start infomancer-frontend

# 验证部署
echo "验证部署..."
sleep 5

# 检查服务状态
backend_status=$(systemctl is-active infomancer-backend)
frontend_status=$(systemctl is-active infomancer-frontend)

if [ "$backend_status" = "active" ] && [ "$frontend_status" = "active" ]; then
    echo "部署成功！"
    echo "后端服务运行在: http://localhost:5000"
    echo "前端服务运行在: http://localhost:4173"
    echo "请确保在防火墙中开放了相应端口"
    echo "可以通过以下命令查看服务日志："
    echo "后端日志: journalctl -u infomancer-backend -f"
    echo "前端日志: journalctl -u infomancer-frontend -f"
else
    echo "部署可能存在问题，请检查服务状态："
    echo "systemctl status infomancer-backend"
    echo "systemctl status infomancer-frontend"
    exit 1
fi